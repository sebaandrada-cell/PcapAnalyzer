# PcapAnalyzer

Analizador web de capturas de red `.pcap` / `.pcapng` (ver [SPEC.md](SPEC.md)): subes una captura y obtienes un dashboard con métricas, conversaciones, problemas detectados automáticamente, diagnóstico asistido por IA e informe PDF exportable. Las cuatro fases del SPEC están completadas: backend FastAPI + `tshark`, frontend React + Recharts, capa IA (Anthropic API) y empaquetado on-premise con Docker Compose.

## Arquitectura

```
wireapp/
├── backend/                  # Fase 1 (actual): API de análisis
│   ├── app/
│   │   ├── main.py           # Capa HTTP (FastAPI): /health, /analyze
│   │   ├── config.py         # Umbrales y configuración vía variables de entorno
│   │   ├── models.py         # Modelos Pydantic = contrato JSON de la API
│   │   ├── tshark.py         # Descubrimiento e invocación de tshark (subprocess + JSON)
│   │   ├── analysis/
│   │   │   └── engine.py     # Motor: una sola pasada sobre los paquetes
│   │   ├── llm/              # Fase 3: capa IA (Anthropic API)
│   │   │   ├── context.py    # Resumen JSON compacto que recibe el modelo
│   │   │   ├── prompts.py    # System prompts + esquema de salida estructurada
│   │   │   ├── service.py    # /diagnose y /query contra la Anthropic API
│   │   │   └── router.py     # Endpoints FastAPI
│   │   └── detectors/        # Un módulo por patrón, interfaz común detect(state)
│   │       ├── tcp_syn_rst.py
│   │       ├── tcp_retransmissions.py
│   │       ├── dns_problems.py
│   │       ├── tcp_zero_window.py
│   │       ├── tls_alerts.py
│   │       ├── mtu_mss.py
│   │       ├── ip_fragmentation.py
│   │       ├── vpn_tunnels.py
│   │       ├── tcp_handshake.py
│   │       ├── dns_errors.py
│   │       └── duplicate_ip.py
│   ├── tests/
│   │   ├── pcap_builder.py   # Genera el pcap sintético de fixtures (sin scapy)
│   │   ├── test_detectors.py # Test unitario por detector (sin tshark)
│   │   └── test_analyze.py   # Tests de integración del endpoint
│   ├── requirements.txt
│   └── requirements-dev.txt
├── docs/mockup.png           # Mockup de referencia del dashboard
└── frontend/                 # Fase 2 (actual): dashboard React + Recharts
    ├── src/api.ts            # Tipos espejo del contrato (models.py) + cliente
    ├── src/format.ts         # Formato es-ES (bytes, duración, números)
    └── src/components/       # UploadScreen, Header, QueryBar, MetricCards,
                              # ProtocolBars, TopTalkers, TrafficChart,
                              # IssuesList, ConversationModal, DiagnosisPanel
```

Decisiones pensadas para las fases siguientes:

- **La capa HTTP es mínima.** Toda la lógica vive en `app.analysis.analyze_pcap()`, una función pura reutilizable desde la capa IA (Fase 3) o un CLI sin pasar por HTTP. El LLM recibirá este JSON resumido, nunca el pcap crudo.
- **`app/models.py` es el contrato.** Los modelos Pydantic definen el JSON que consumirá el frontend React. FastAPI publica el esquema OpenAPI en `/docs`.
- **Detectores enchufables.** Cada patrón es un módulo en `app/detectors/` con la misma interfaz (`detect(state) -> List[Issue]`); añadir uno nuevo = nuevo módulo + registrarlo en `DETECTORS` + (si necesita campos nuevos) añadirlos a `FIELDS` en `tshark.py`.
- **CORS ya configurado** para `localhost:5173` / `localhost:3000` (variable `CORS_ORIGINS`).
- **Stateless, sin base de datos**: el pcap subido se analiza y se borra.

### Por qué tshark por subprocess (y no pyshark)

pyshark envuelve tshark con parsing XML/JSON pesado y es demasiado lento para capturas grandes. Aquí se hace **una única invocación** de `tshark -T ek` (JSON delimitado por líneas) con `-e` para extraer solo los ~25 campos necesarios, y el motor la consume en streaming: una sola pasada y memoria plana independientemente del tamaño de la captura.

## Requisitos

- Python 3.9+
- **tshark** (viene con Wireshark). Comprobación: `tshark --version`
  - macOS: `brew install wireshark` (solo CLI) o `brew install --cask wireshark` (app completa). Si Wireshark.app está instalada manualmente, el backend también encuentra `/Applications/Wireshark.app/Contents/MacOS/tshark`.
  - Debian/Ubuntu: `sudo apt install tshark`
  - Fedora: `sudo dnf install wireshark-cli`
  - Windows: instalador de [wireshark.org](https://www.wireshark.org/download.html)
  - Ruta no estándar: exporta `TSHARK_PATH=/ruta/a/tshark`

La presencia de tshark se comprueba al arrancar (se loguea con claridad si falta) y `GET /health` la expone; sin tshark, `/analyze` responde `503` con las instrucciones de instalación.

## Puesta en marcha

### Con Docker (variante on-premise, Fase 4)

```bash
export ANTHROPIC_API_KEY=sk-ant-...   # opcional: habilita la capa IA
docker compose up --build
```

Aplicación completa en <http://localhost:8080> (puerto configurable con `PCAPANALYZER_PORT`). El backend se construye con Python 3.12 + tshark y corre como usuario sin privilegios; nginx sirve el frontend y proxya la API. *Nota: los Dockerfiles no se han podido construir en esta máquina (sin Docker); si algo falla en el primer `docker compose up`, revisa la instalación de `tshark` en la imagen.*

### En local (desarrollo)

Backend (puerto 8000):

```bash
cd backend
python3 -m venv .venv
.venv/bin/pip install -r requirements-dev.txt
.venv/bin/uvicorn app.main:app --reload
```

API docs interactivas en <http://127.0.0.1:8000/docs>.

Frontend (puerto 5173, requiere Node 20+ y el backend arrancado):

```bash
cd frontend
npm install
npm run dev
```

Dashboard en <http://localhost:5173>. El dev server de Vite proxya `/analyze` y `/health` al backend (sin CORS en desarrollo); para otro despliegue, define `VITE_API_URL`. La pantalla de subida acepta drag&drop e incluye un botón **"Probar con la captura de ejemplo"** (sirve `frontend/public/sample.pcap`, copia del fixture de tests).

### Qué incluye el dashboard (Fase 2)

- Cabecera con metadatos del archivo y barra de consulta en lenguaje natural (deshabilitada hasta la Fase 3).
- Tarjetas de métricas: paquetes, duración, conversaciones y problemas detectados.
- Distribución de protocolos (barras horizontales) y top talkers con marca ⚠ en hosts implicados en issues, más túneles VPN detectados.
- Gráfico temporal (Recharts): paquetes/s en azul y retransmisiones/s en rojo, con tooltip; los segundos sin tráfico se rellenan con ceros.
- **Lista de paquetes estilo Wireshark** (nº, tiempo, origen, destino, protocolo, longitud e info) con filtro de texto libre, chips de filtrado rápido por protocolo y columnas ordenables; limitada a los primeros `PACKET_LIST_MAX` (1000) paquetes de la captura.
- **Tabla de consultas DNS** con el desenlace de cada consulta (OK / lenta / sin respuesta / SERVFAIL / NXDOMAIN) y su latencia.
- **Tabla de peticiones HTTP** (método, host+URI y código de respuesta emparejado por stream, o "Sin respuesta").
- **Propiedades de la captura** (primer/último paquete, tamaño medio, tasas) al estilo *Capture File Properties* de Wireshark.
- **Tiempos de respuesta de servicio (SRT)**: latencia mín/media/máx por protocolo (DNS, handshake TCP, HTTP).
- **Sesiones TLS**: versión, cipher, SNI y alerta por stream. Todo esto también aparece en el informe PDF.
- Lista de problemas con badges de severidad (Crítico/Aviso/Info).
- Drill-down: clic en un issue con conversación asociada o en un top talker abre el detalle de la conversación TCP (bytes por sentido, retransmisiones, MSS, RTT de handshake, eventos window 0 e issues relacionados), con un **diagrama de flujo** (ladder diagram estilo Wireshark) del intercambio de paquetes entre los dos extremos.
- Panel "Diagnóstico asistido" y barra de consulta en lenguaje natural conectados a la capa IA (Fase 3).
- **Modo claro/oscuro e idioma (ES/EN)** con toggles en la barra de configuración (arriba a la derecha); la preferencia se guarda en el navegador. En inglés, el diagnóstico y las consultas de IA también responden en inglés. Nota: el texto de los problemas autodetectados lo generan los detectores del backend y por ahora se muestra siempre en español.
- **Recuperación de errores de UI**: un error inesperado de render muestra un aviso recargable en vez de dejar la página en blanco.

### Capa IA (Fase 3)

Dos endpoints que envían a la Anthropic API **solo el resumen JSON del análisis** (recortado a un máximo de issues/conversaciones), **nunca la captura**:

- `POST /diagnose` — diagnóstico narrativo en español: *qué está pasando, causa probable y siguiente paso recomendado*. En la UI: botón "Generar diagnóstico" del panel inferior.
- `POST /query` — traduce una pregunta en lenguaje natural ("conexiones fallidas hacia el servidor de correo") a un **display filter de Wireshark**, con explicación y la lista de conversaciones/issues del análisis que coinciden; la UI muestra el filtro generado y resalta los problemas relacionados.

**Configurar la capa IA** — dos opciones:

1. **IA real**: copia `backend/.env.example` a `backend/.env`, pega tu clave en `ANTHROPIC_API_KEY` y reinicia el backend (el `.env` se carga automáticamente y está en `.gitignore`). Con Docker Compose basta un `.env` en la raíz del proyecto con la misma variable.
2. **Modo demo** (`LLM_DEMO=1` en el `.env`): respuestas simuladas generadas desde el propio análisis, sin llamar a la API — sin coste ni credenciales. El diagnóstico y las explicaciones se marcan como "(modo demo)".

Sin credenciales ni modo demo, `GET /health` lo indica (`ai.available: false`) y los endpoints devuelven `503` con instrucciones; el resto de la aplicación funciona con normalidad. Variables: `LLM_MODEL` (por defecto `claude-opus-4-8`), `LLM_MAX_TOKENS` (4096), `LLM_TIMEOUT_S` (120), `LLM_DEMO`. Los strings procedentes de la captura se tratan como datos no confiables también en los prompts.

### Informe PDF y capturas grandes (Fase 4)

- `POST /report` — genera un **informe PDF en español** (resumen, problemas con severidad, diagnóstico IA si se generó, protocolos, top talkers, conversaciones, túneles) listo para entregar a un cliente. En la UI: botón "⇩ Exportar informe" de la cabecera.
- `POST /analyze/async` + `GET /jobs/{id}` — **cola de análisis en segundo plano** (pool de hilos en proceso, sin broker externo) para capturas grandes; el frontend la usa automáticamente para archivos de más de 20 MB, con polling. Los resultados expiran tras `JOB_TTL_S` (3600 s) y la captura subida se borra al terminar su análisis. Variables: `ANALYZE_WORKERS` (2), `JOB_TTL_S`.

## Uso

```bash
curl -s -F "file=@captura.pcap" http://127.0.0.1:8000/analyze | jq .
```

### Respuesta (resumen del esquema)

```jsonc
{
  "file":     { "name": "captura.pcap", "size_bytes": 1570 },
  "summary":  { "packets": 20, "bytes": 1570, "duration_seconds": 5.0,
                "conversations": 6, "avg_packets_per_second": 4.0, ... },
  "protocols": [ { "protocol": "tcp", "packets": 12, "bytes": 900,
                   "packet_pct": 60.0, "bytes_pct": 57.3 }, ... ],
  "time_series": [ { "t": 0, "packets": 8, "bytes": 830, "retransmissions": 2 }, ... ],
  "conversations": {
    "tcp": [ { "stream_id": 0, "src": "10.0.0.1", "src_port": 34567,
               "dst": "10.0.0.2", "dst_port": 80, "packets": 8, "bytes": 830,
               "retransmissions": 2, "retransmission_pct": 25.0,
               "zero_window_events": 1, ... } ],
    "udp": [ ... ],
    "top_talkers": [ { "address": "10.0.0.1", "bytes_sent": 1006,
                       "bytes_received": 480, "bytes_total": 1486, ... } ]
  },
  "tunnels": [ { "type": "esp", "peer_a": "10.0.0.1", "peer_b": "10.0.0.6",
                 "packets": 4, "packets_a_to_b": 4, "packets_b_to_a": 0,
                 "bytes": 328 } ],
  "issues": [
    { "id": "tcp-syn-rst-1", "type": "tcp_syn_rst", "severity": "critical",
      "title": "SYN respondido con RST inmediato",
      "detail": "...", "conversation": "10.0.0.1:34568 <-> 10.0.0.3:8443",
      "evidence": { "syn_to_rst_ms": 5.0, "dst_port": 8443 } }
  ],
  "meta": { "engine_version": "0.1.0", "tshark_version": "TShark ... 4.6.6",
            "analysis_duration_ms": 150 }
}
```

`time_series` es dispersa (solo segundos con tráfico); `t` es el offset en segundos desde el inicio de la captura. Las conversaciones TCP incluyen además `mss_client`, `mss_server` y `handshake_rtt_ms`. `tunnels` identifica pasivamente tráfico VPN/túnel: ESP, IKE/ISAKMP, WireGuard, OpenVPN, GRE y L2TP.

### Detectores (`issues`)

| Tipo | Detección | Severidad |
|---|---|---|
| `tcp_syn_rst` | SYN respondido con RST sin SYN-ACK en < 1 s → firewall / puerto cerrado | `critical` |
| `tcp_retransmissions` | % de retransmisiones por conversación (`tcp.analysis.retransmission` + fast/spurious) | `critical` > 2 %, `warning` > 1 % |
| `dns_unanswered` | Consulta DNS sin respuesta en toda la captura | `warning` |
| `dns_slow` | Respuesta DNS con latencia > 500 ms | `warning` |
| `tcp_zero_window` | Anuncios de ventana TCP 0 → receptor saturado | `warning` |
| `tls_handshake_failure` | Alerta TLS `handshake_failure` (código 40) | `warning` |
| `tls_alert` | Otras alertas TLS fatales (bad_certificate, unknown_ca, …) | `warning` |
| `ip_duplicate` | La misma IP anunciada por ≥ 2 MACs vía ARP (conflicto de IP / ARP spoofing) | `critical` |
| `ike_no_response` | ≥ 2 mensajes IKE sin ninguna respuesta → la VPN no levanta | `critical` |
| `ike_handshake_incomplete` | IKE bidireccional pero sin tráfico ESP posterior entre esos peers | `warning` |
| `esp_one_way` | ESP/WireGuard/OpenVPN en un solo sentido (≥ 3 paquetes) → túnel roto | `warning` |
| `ip_fragments_incomplete` | Datagramas fragmentados sin su último fragmento → imposibles de reensamblar | `critical` |
| `ip_fragmentation_high` | > 5 % de los paquetes son fragmentos IP | `warning` |
| `icmp_frag_needed` | ICMP Fragmentation Needed / ICMPv6 Packet Too Big (MTU del camino) | `warning` |
| `pmtud_blackhole` | ≥ 3 retransmisiones de segmentos tamaño-MSS sin ningún ICMP frag-needed → PMTUD roto | `warning` |
| `mss_low` | MSS negociado < 1300 bytes (overhead de túnel/VPN en el camino) | `info` |
| `tcp_slow_handshake` | SYN → SYN-ACK > 500 ms (latencia alta o servidor saturado) | `warning` |
| `dns_servfail` | Respuestas SERVFAIL de un servidor DNS | `warning` |
| `dns_nxdomain` | Ráfaga de ≥ 3 NXDOMAIN hacia un mismo cliente (sufijo mal configurado / DGA) | `warning` |

Umbrales configurables por entorno (`app/config.py`, nada hardcodeado): `RETRANS_WARN_PCT`, `RETRANS_CRIT_PCT`, `RETRANS_MIN_PACKETS`, `SYN_RST_MAX_DELAY_S`, `DNS_SLOW_THRESHOLD_S`, `DNS_NXDOMAIN_MIN`, `TCP_HANDSHAKE_SLOW_S`, `MSS_LOW_THRESHOLD`, `PMTUD_MIN_FULLSIZE_RETRANS`, `FRAG_HIGH_PCT`, `ESP_ONE_WAY_MIN`, `IKE_NO_RESPONSE_MIN`. Otras variables: `MAX_UPLOAD_MB` (200), `TSHARK_TIMEOUT_S` (300), `TSHARK_PATH`, `CORS_ORIGINS`, `TOP_TALKERS_LIMIT`.

### Errores

| Código | Causa |
|---|---|
| `400` | El archivo no es un pcap/pcapng (magic number) o está vacío |
| `413` | Supera `MAX_UPLOAD_MB` |
| `422` | tshark no pudo procesar el archivo |
| `503` | tshark no está instalado (el detalle incluye cómo instalarlo) |
| `504` | El análisis excedió `TSHARK_TIMEOUT_S` |

## Tests

```bash
cd backend
.venv/bin/python -m pytest tests/ -v
```

- `test_detectors.py`: un test unitario por detector sobre estados sintéticos (no requiere tshark).
- `test_analyze.py`: integración del endpoint contra `tests/fixtures/sample.pcap`, regenerado de forma determinista en cada ejecución por [pcap_builder.py](backend/tests/pcap_builder.py) (paquetes crafteados a mano, sin scapy). El fixture contiene deliberadamente: retransmisiones TCP (25 % de un stream), un SYN→RST inmediato, un zero window, un handshake TLS que termina en `handshake_failure`, consultas DNS rápida / lenta (700 ms) / sin respuesta, un stream con MSS 1240 y agujero negro PMTUD, un handshake de 600 ms, un ICMP Fragmentation Needed, un datagrama fragmentado completo y otro incompleto, ESP unidireccional, IKE sin respuesta e IKE sin ESP posterior, un SERVFAIL, tres NXDOMAIN y una IP duplicada anunciada por dos MACs. Estos tests se saltan automáticamente si tshark no está instalado.

Seguridad: nunca se loguean payloads, el archivo subido se borra tras el análisis, hay límite de tamaño de subida y los strings extraídos de la captura (p. ej. nombres DNS) se sanean antes de incluirse en la respuesta.

## Roadmap

- **Fase 1:** backend de análisis con tshark ✔
- **Fase 2:** frontend React + Recharts según `docs/mockup.png` ✔
- **Fase 3:** capa IA — diagnóstico narrativo y lenguaje natural → display filter ✔
- **Fase 4:** Docker Compose (on-premise), informe PDF exportable y cola async para capturas grandes ✔

Ideas post-MVP: multiusuario/planes (freemium B2B), descifrado TLS con claves del usuario, persistencia opcional de análisis, workers externos (Redis/RQ) si la cola en proceso se queda corta.
