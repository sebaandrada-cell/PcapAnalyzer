import { useCallback, useState } from 'react'
import type { AnalysisResult, Issue, QueryResponse, TopTalker } from './api'
import { ASYNC_THRESHOLD_BYTES, analyzePcap, analyzePcapAsync, queryFilter } from './api'
import CaptureProperties from './components/CaptureProperties'
import ConversationModal, { type Selection } from './components/ConversationModal'
import DiagnosisPanel from './components/DiagnosisPanel'
import DnsQueries from './components/DnsQueries'
import Header from './components/Header'
import HttpRequests from './components/HttpRequests'
import ServiceResponseTimes from './components/ServiceResponseTimes'
import TlsSessions from './components/TlsSessions'
import PacketList from './components/PacketList'
import IssuesList, { issueStreamId } from './components/IssuesList'
import MetricCards from './components/MetricCards'
import ProtocolBars from './components/ProtocolBars'
import QueryBar from './components/QueryBar'
import SettingsBar from './components/SettingsBar'
import TopTalkers from './components/TopTalkers'
import TrafficChart from './components/TrafficChart'
import UploadScreen from './components/UploadScreen'
import { useSettings } from './settings'

export default function App() {
  const { t, lang } = useSettings()
  const [result, setResult] = useState<AnalysisResult | null>(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [selection, setSelection] = useState<Selection | null>(null)
  const [query, setQuery] = useState<QueryResponse | null>(null)
  const [queryLoading, setQueryLoading] = useState(false)
  const [queryError, setQueryError] = useState<string | null>(null)
  const [diagnosis, setDiagnosis] = useState<string | null>(null)

  const handleFile = useCallback((file: File) => {
    setAnalyzing(true)
    setError(null)
    setQuery(null)
    setQueryError(null)
    setDiagnosis(null)
    // Large captures go through the async queue instead of blocking /analyze.
    const analyze = file.size > ASYNC_THRESHOLD_BYTES ? analyzePcapAsync : analyzePcap
    analyze(file)
      .then(setResult)
      .catch((err: Error) => setError(err.message))
      .finally(() => setAnalyzing(false))
  }, [])

  const handleQuery = useCallback(
    (question: string) => {
      if (!result) return
      setQueryLoading(true)
      setQueryError(null)
      queryFilter(question, result, lang)
        .then(setQuery)
        .catch((err: Error) => setQueryError(err.message))
        .finally(() => setQueryLoading(false))
    },
    [result, lang],
  )

  const clearQuery = useCallback(() => {
    setQuery(null)
    setQueryError(null)
  }, [])

  const handleIssueSelect = useCallback((issue: Issue) => {
    const streamId = issueStreamId(issue)
    if (streamId !== null) setSelection({ view: 'conv', streamId })
  }, [])

  const handleTalkerSelect = useCallback((talker: TopTalker) => {
    setSelection({ view: 'host', address: talker.address })
  }, [])

  if (!result) {
    return (
      <>
        <SettingsBar />
        <UploadScreen analyzing={analyzing} error={error} onFile={handleFile} />
      </>
    )
  }

  return (
    <>
      <SettingsBar />
      <Header
        result={result}
        diagnosis={diagnosis}
        onReset={() => {
          setResult(null)
          setSelection(null)
          setQuery(null)
          setQueryError(null)
          setDiagnosis(null)
        }}
      />
      <QueryBar
        loading={queryLoading}
        result={query}
        error={queryError}
        onSubmit={handleQuery}
        onClear={clearQuery}
      />
      <MetricCards result={result} />
      <div className="columns">
        <ProtocolBars protocols={result.protocols} />
        <TopTalkers result={result} onSelect={handleTalkerSelect} />
      </div>
      <TrafficChart series={result.time_series} duration={result.summary.duration_seconds} />
      <CaptureProperties result={result} />
      <ServiceResponseTimes rows={result.service_response_times} />
      <PacketList data={result.packet_list} />
      <HttpRequests requests={result.http_requests} />
      <DnsQueries queries={result.dns_queries} />
      <TlsSessions sessions={result.tls_sessions} />
      <IssuesList
        issues={result.issues}
        highlightedIds={query ? new Set(query.matched_issue_ids) : null}
        onSelect={handleIssueSelect}
      />
      <DiagnosisPanel analysis={result} onGenerated={setDiagnosis} />
      <div className="footer-note">
        {t('footer.note', { version: result.meta.engine_version })}
      </div>
      {selection && (
        <ConversationModal
          result={result}
          selection={selection}
          onNavigate={setSelection}
          onClose={() => setSelection(null)}
        />
      )}
    </>
  )
}
