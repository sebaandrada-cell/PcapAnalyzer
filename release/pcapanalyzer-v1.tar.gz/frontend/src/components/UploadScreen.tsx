import { useCallback, useEffect, useRef, useState } from 'react'
import { useSettings } from '../settings'

interface HealthTshark {
  available: boolean
  install_hint: string | null
}

interface Props {
  analyzing: boolean
  error: string | null
  onFile: (file: File) => void
}

export default function UploadScreen({ analyzing, error, onFile }: Props) {
  const { t } = useSettings()
  const inputRef = useRef<HTMLInputElement>(null)
  const [drag, setDrag] = useState(false)
  const [tsharkHint, setTsharkHint] = useState<string | null>(null)

  useEffect(() => {
    fetch('/health')
      .then((r) => r.json())
      .then((h: { tshark?: HealthTshark }) => {
        if (h.tshark && !h.tshark.available) setTsharkHint(h.tshark.install_hint)
      })
      .catch(() => {
        setTsharkHint(t('upload.backendError'))
      })
  }, [t])

  const handleDrop = useCallback(
    (event: React.DragEvent) => {
      event.preventDefault()
      setDrag(false)
      const file = event.dataTransfer.files[0]
      if (file) onFile(file)
    },
    [onFile],
  )

  const loadSample = useCallback(async () => {
    const response = await fetch('/sample.pcap')
    const blob = await response.blob()
    onFile(new File([blob], 'sample.pcap', { type: 'application/octet-stream' }))
  }, [onFile])

  return (
    <div className="upload-wrap">
      <h1>PcapAnalyzer</h1>
      <p className="sub">{t('upload.subtitle')}</p>

      <div
        className={`dropzone${drag ? ' drag' : ''}`}
        onClick={() => inputRef.current?.click()}
        onDragOver={(event) => {
          event.preventDefault()
          setDrag(true)
        }}
        onDragLeave={() => setDrag(false)}
        onDrop={handleDrop}
      >
        <div className="big">{analyzing ? t('upload.analyzing') : t('upload.drop')}</div>
        <div className="hint">{t('upload.hint')}</div>
        <input
          ref={inputRef}
          type="file"
          accept=".pcap,.pcapng,.cap"
          hidden
          onChange={(event) => {
            const file = event.target.files?.[0]
            if (file) onFile(file)
            event.target.value = ''
          }}
        />
      </div>

      <div className="upload-actions">
        <button onClick={loadSample} disabled={analyzing}>
          {t('upload.sample')}
        </button>
      </div>

      {error && <div className="upload-error">{error}</div>}
      {tsharkHint && <div className="tshark-warn">{tsharkHint}</div>}
    </div>
  )
}
