import { useSettings } from '../settings'

// Compact settings control (top-right): theme and language toggles.
export default function SettingsBar() {
  const { t, theme, setTheme, lang, setLang } = useSettings()
  return (
    <div className="settings-bar">
      <div className="seg" role="group" aria-label={t('settings.theme')}>
        <button
          className={theme === 'light' ? 'seg-btn active' : 'seg-btn'}
          onClick={() => setTheme('light')}
          title={t('settings.light')}
        >
          ☀ {t('settings.light')}
        </button>
        <button
          className={theme === 'dark' ? 'seg-btn active' : 'seg-btn'}
          onClick={() => setTheme('dark')}
          title={t('settings.dark')}
        >
          ☾ {t('settings.dark')}
        </button>
      </div>
      <div className="seg" role="group" aria-label={t('settings.language')}>
        <button
          className={lang === 'es' ? 'seg-btn active' : 'seg-btn'}
          onClick={() => setLang('es')}
        >
          ES
        </button>
        <button
          className={lang === 'en' ? 'seg-btn active' : 'seg-btn'}
          onClick={() => setLang('en')}
        >
          EN
        </button>
      </div>
    </div>
  )
}
