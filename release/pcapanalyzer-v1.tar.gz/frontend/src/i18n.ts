// Lightweight i18n: a nested dictionary + a t() lookup with {var} interpolation.
// UI chrome is fully translated ES/EN; AI-generated text (diagnosis, issue
// descriptions) is produced by the backend in the requested language.

export type Lang = 'es' | 'en'

type Dict = { [key: string]: string | Dict }

const es: Dict = {
  settings: {
    title: 'Configuración',
    theme: 'Tema',
    light: 'Claro',
    dark: 'Oscuro',
    language: 'Idioma',
  },
  common: { close: 'Cerrar', clear: 'Limpiar', retry: 'Reintentar' },
  upload: {
    subtitle: 'Sube una captura .pcap / .pcapng y obtén un dashboard con los problemas detectados.',
    analyzing: 'Analizando captura…',
    drop: 'Arrastra tu captura aquí',
    hint: 'o haz clic para elegir un archivo (máx. 200 MB)',
    sample: 'Probar con la captura de ejemplo',
    backendError: 'No se pudo contactar con el backend (¿está arrancado en :8000?).',
  },
  header: {
    analyzeAnother: 'Analizar otra captura',
    export: '⇩ Exportar informe',
    exporting: 'Generando…',
    exportTitle: 'Descargar informe PDF',
    meta: '{bytes} · {dur} de captura · analizado en {ms} ms · {tshark}',
  },
  query: {
    placeholder: 'Muéstrame las conexiones fallidas hacia el servidor de correo',
    ask: '✨ Consultar',
    asking: 'Consultando…',
    generated: 'Filtro generado:',
    related: '{n} problema(s) relacionados resaltados',
  },
  metrics: {
    packets: 'Paquetes',
    duration: 'Duración',
    conversations: 'Conversaciones',
    problems: 'Problemas detectados',
  },
  protocols: { title: 'Distribución de protocolos', other: 'Otros' },
  talkers: {
    title: 'Top talkers',
    tunnels: 'Túneles VPN detectados',
    viewConvs: 'Ver conversaciones de este host',
  },
  chart: {
    title: 'Tráfico en el tiempo',
    sub: 'Paquetes por segundo · los picos rojos marcan ráfagas de retransmisiones',
    packetsPerSec: 'Paquetes/s',
    retransPerSec: 'Retransmisiones/s',
  },
  packets: {
    title: 'Paquetes',
    filter: 'Filtrar: dns, 10.0.0.2, RST, retransmission…',
    all: 'Todos',
    colNo: 'Nº',
    colTime: 'Tiempo',
    colSrc: 'Origen',
    colDst: 'Destino',
    colProto: 'Protocolo',
    colLen: 'Long.',
    colInfo: 'Info',
    sort: 'Ordenar',
    empty: 'Ningún paquete coincide con el filtro.',
    foot: 'Mostrando {shown} de {total} paquetes',
    footTrunc: ' (lista limitada a los primeros {n} de {captured} de la captura)',
  },
  http: {
    title: 'Peticiones HTTP',
    colTime: 'Tiempo',
    colClient: 'Cliente',
    colServer: 'Servidor',
    colMethod: 'Método',
    colUrl: 'URL',
    colStatus: 'Estado',
    noResponse: 'Sin respuesta',
  },
  dns: {
    title: 'Consultas DNS',
    colName: 'Nombre',
    colClient: 'Cliente',
    colServer: 'Servidor',
    colStatus: 'Estado',
    colLatency: 'Latencia',
    ok: 'OK',
    slow: 'Lenta',
    unanswered: 'Sin respuesta',
    servfail: 'SERVFAIL',
    nxdomain: 'NXDOMAIN',
  },
  capture: {
    title: 'Propiedades de la captura',
    filename: 'Archivo',
    size: 'Tamaño',
    firstPacket: 'Primer paquete',
    lastPacket: 'Último paquete',
    elapsed: 'Duración',
    packets: 'Paquetes',
    avgSize: 'Tamaño medio',
    avgRate: 'Media paquetes/s',
    avgBitrate: 'Media bytes/s',
  },
  srt: {
    title: 'Tiempos de respuesta (SRT)',
    sub: 'Latencia petición → respuesta por protocolo',
    colProto: 'Protocolo',
    colSamples: 'Muestras',
    colMin: 'Mín',
    colAvg: 'Media',
    colMax: 'Máx',
  },
  tls: {
    title: 'Sesiones TLS',
    colStream: 'Stream',
    colClient: 'Cliente',
    colServer: 'Servidor',
    colVersion: 'Versión',
    colCipher: 'Cipher',
    colSni: 'SNI',
    colAlert: 'Alerta',
  },
  issues: {
    title: '⚠ Problemas detectados',
    none: 'No se detectó ningún problema en esta captura.',
    viewConv: 'Ver conversación',
    critical: 'Crítico',
    warning: 'Aviso',
    info: 'Info',
  },
  diagnosis: {
    title: '✨ Diagnóstico asistido',
    intro:
      'Genera un diagnóstico narrativo con IA: qué pasa, causa probable y siguiente paso recomendado. Solo se envía el resumen JSON del análisis, nunca la captura.',
    generate: 'Generar diagnóstico',
    loading: 'Analizando la captura con IA…',
    regenerate: 'Regenerar',
  },
  flow: {
    title: 'Diagrama de flujo',
    more: '+{n} paquetes más',
  },
  modal: {
    convProblems: 'Problemas en esta conversación',
    tcpConvs: 'Conversaciones TCP',
    udpConvs: 'Conversaciones UDP',
    hostTitle: 'Conversaciones de {addr}',
    viewDetail: 'Ver detalle',
    packets: 'Paquetes',
    totalBytes: 'Bytes totales',
    c2s: 'Cliente → servidor',
    s2c: 'Servidor → cliente',
    duration: 'Duración',
    retrans: 'Retransmisiones',
    zeroWin: 'Eventos window 0',
    mssClient: 'MSS cliente',
    mssServer: 'MSS servidor',
    rtt: 'RTT handshake',
  },
  footer: {
    note: 'PcapAnalyzer · motor {version} · el archivo se analiza y se descarta, no se almacena.',
  },
  boundary: {
    title: 'Algo ha fallado',
    body: 'La interfaz encontró un error inesperado. Recarga la página para continuar.',
    reload: 'Recargar',
  },
}

const en: Dict = {
  settings: {
    title: 'Settings',
    theme: 'Theme',
    light: 'Light',
    dark: 'Dark',
    language: 'Language',
  },
  common: { close: 'Close', clear: 'Clear', retry: 'Retry' },
  upload: {
    subtitle: 'Upload a .pcap / .pcapng capture and get a dashboard with the detected problems.',
    analyzing: 'Analyzing capture…',
    drop: 'Drop your capture here',
    hint: 'or click to choose a file (max 200 MB)',
    sample: 'Try the sample capture',
    backendError: "Couldn't reach the backend (is it running on :8000?).",
  },
  header: {
    analyzeAnother: 'Analyze another capture',
    export: '⇩ Export report',
    exporting: 'Generating…',
    exportTitle: 'Download PDF report',
    meta: '{bytes} · {dur} capture · analyzed in {ms} ms · {tshark}',
  },
  query: {
    placeholder: 'Show me the failed connections to the mail server',
    ask: '✨ Query',
    asking: 'Querying…',
    generated: 'Generated filter:',
    related: '{n} related issue(s) highlighted',
  },
  metrics: {
    packets: 'Packets',
    duration: 'Duration',
    conversations: 'Conversations',
    problems: 'Problems detected',
  },
  protocols: { title: 'Protocol distribution', other: 'Other' },
  talkers: {
    title: 'Top talkers',
    tunnels: 'Detected VPN tunnels',
    viewConvs: "View this host's conversations",
  },
  chart: {
    title: 'Traffic over time',
    sub: 'Packets per second · red spikes mark retransmission bursts',
    packetsPerSec: 'Packets/s',
    retransPerSec: 'Retransmissions/s',
  },
  packets: {
    title: 'Packets',
    filter: 'Filter: dns, 10.0.0.2, RST, retransmission…',
    all: 'All',
    colNo: 'No.',
    colTime: 'Time',
    colSrc: 'Source',
    colDst: 'Destination',
    colProto: 'Protocol',
    colLen: 'Len.',
    colInfo: 'Info',
    sort: 'Sort',
    empty: 'No packets match the filter.',
    foot: 'Showing {shown} of {total} packets',
    footTrunc: ' (list limited to the first {n} of {captured} in the capture)',
  },
  http: {
    title: 'HTTP requests',
    colTime: 'Time',
    colClient: 'Client',
    colServer: 'Server',
    colMethod: 'Method',
    colUrl: 'URL',
    colStatus: 'Status',
    noResponse: 'No response',
  },
  dns: {
    title: 'DNS queries',
    colName: 'Name',
    colClient: 'Client',
    colServer: 'Server',
    colStatus: 'Status',
    colLatency: 'Latency',
    ok: 'OK',
    slow: 'Slow',
    unanswered: 'Unanswered',
    servfail: 'SERVFAIL',
    nxdomain: 'NXDOMAIN',
  },
  capture: {
    title: 'Capture properties',
    filename: 'File',
    size: 'Size',
    firstPacket: 'First packet',
    lastPacket: 'Last packet',
    elapsed: 'Duration',
    packets: 'Packets',
    avgSize: 'Avg size',
    avgRate: 'Avg packets/s',
    avgBitrate: 'Avg bytes/s',
  },
  srt: {
    title: 'Service response times (SRT)',
    sub: 'Request → response latency per protocol',
    colProto: 'Protocol',
    colSamples: 'Samples',
    colMin: 'Min',
    colAvg: 'Avg',
    colMax: 'Max',
  },
  tls: {
    title: 'TLS sessions',
    colStream: 'Stream',
    colClient: 'Client',
    colServer: 'Server',
    colVersion: 'Version',
    colCipher: 'Cipher',
    colSni: 'SNI',
    colAlert: 'Alert',
  },
  issues: {
    title: '⚠ Detected problems',
    none: 'No problems detected in this capture.',
    viewConv: 'View conversation',
    critical: 'Critical',
    warning: 'Warning',
    info: 'Info',
  },
  diagnosis: {
    title: '✨ AI diagnosis',
    intro:
      'Generate a narrative diagnosis with AI: what is happening, likely cause and recommended next step. Only the analysis JSON summary is sent, never the capture.',
    generate: 'Generate diagnosis',
    loading: 'Analyzing the capture with AI…',
    regenerate: 'Regenerate',
  },
  flow: {
    title: 'Flow graph',
    more: '+{n} more packets',
  },
  modal: {
    convProblems: 'Problems in this conversation',
    tcpConvs: 'TCP conversations',
    udpConvs: 'UDP conversations',
    hostTitle: 'Conversations for {addr}',
    viewDetail: 'View detail',
    packets: 'Packets',
    totalBytes: 'Total bytes',
    c2s: 'Client → server',
    s2c: 'Server → client',
    duration: 'Duration',
    retrans: 'Retransmissions',
    zeroWin: 'Zero-window events',
    mssClient: 'MSS client',
    mssServer: 'MSS server',
    rtt: 'Handshake RTT',
  },
  footer: {
    note: 'PcapAnalyzer · engine {version} · the file is analyzed and discarded, not stored.',
  },
  boundary: {
    title: 'Something went wrong',
    body: 'The interface hit an unexpected error. Reload the page to continue.',
    reload: 'Reload',
  },
}

const DICTS: Record<Lang, Dict> = { es, en }

export function translate(lang: Lang, key: string, params?: Record<string, string | number>): string {
  const parts = key.split('.')
  let node: string | Dict | undefined = DICTS[lang]
  for (const part of parts) {
    if (typeof node !== 'object') {
      node = undefined
      break
    }
    node = node[part]
  }
  let text = typeof node === 'string' ? node : key // fall back to the key if missing
  if (params) {
    for (const [name, value] of Object.entries(params)) {
      text = text.replace(new RegExp(`\\{${name}\\}`, 'g'), String(value))
    }
  }
  return text
}
