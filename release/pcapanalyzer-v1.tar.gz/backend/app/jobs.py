"""In-process job queue for large captures (Fase 4).

Deliberately broker-less to keep the on-premise deployment a single container:
a small thread pool analyzes queued pcaps and results are kept in memory with
a TTL. The uploaded file is deleted as soon as its analysis finishes.
"""
from __future__ import annotations

import os
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Dict, Optional

from . import config
from .analysis import analyze_pcap
from .models import AnalysisResult


@dataclass
class Job:
    id: str
    filename: str
    status: str = "queued"  # queued | running | done | error
    created_at: float = field(default_factory=time.time)
    finished_at: Optional[float] = None
    result: Optional[AnalysisResult] = None
    error: Optional[str] = None


class JobStore:
    def __init__(self, workers: int, ttl_s: int):
        self._jobs: Dict[str, Job] = {}
        self._lock = threading.Lock()
        self._executor = ThreadPoolExecutor(max_workers=workers)
        self._ttl_s = ttl_s

    def submit(self, tshark_path: str, pcap_path: str, filename: str,
               size_bytes: int) -> Job:
        job = Job(id=uuid.uuid4().hex, filename=filename)
        with self._lock:
            self._cleanup_locked()
            self._jobs[job.id] = job
        self._executor.submit(self._run, job, tshark_path, pcap_path,
                              filename, size_bytes)
        return job

    def get(self, job_id: str) -> Optional[Job]:
        with self._lock:
            self._cleanup_locked()
            return self._jobs.get(job_id)

    def _run(self, job: Job, tshark_path: str, pcap_path: str,
             filename: str, size_bytes: int) -> None:
        job.status = "running"
        try:
            job.result = analyze_pcap(
                tshark_path=tshark_path, pcap_path=pcap_path,
                original_filename=filename, size_bytes=size_bytes,
            )
            job.status = "done"
        except Exception as exc:
            job.error = str(exc)
            job.status = "error"
        finally:
            job.finished_at = time.time()
            try:
                os.unlink(pcap_path)
            except OSError:
                pass

    def _cleanup_locked(self) -> None:
        now = time.time()
        expired = [
            job_id for job_id, job in self._jobs.items()
            if job.finished_at is not None and now - job.finished_at > self._ttl_s
        ]
        for job_id in expired:
            del self._jobs[job_id]


job_store = JobStore(workers=config.ANALYZE_WORKERS, ttl_s=config.JOB_TTL_S)
