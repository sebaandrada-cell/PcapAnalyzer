"""FastAPI application: HTTP layer over the analysis engine.

Kept deliberately thin — all analysis logic lives in ``app.analysis`` so the
future LLM layer (and any CLI) can reuse it without going through HTTP.
"""
from __future__ import annotations

import logging
import os
import re
import tempfile
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, File, HTTPException, Response, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from . import __version__, config
from .analysis import analyze_pcap
from .jobs import job_store
from .llm.client import availability as ai_availability
from .llm.router import router as ai_router
from .models import AnalysisResult
from .report import build_report
from .tshark import (
    TsharkError,
    TsharkTimeoutError,
    find_tshark,
    install_instructions,
    tshark_version,
)

# Magic numbers: classic pcap (micro/nanosecond, both endians) and pcapng.
_PCAP_MAGICS = {
    b"\xa1\xb2\xc3\xd4",
    b"\xd4\xc3\xb2\xa1",
    b"\xa1\xb2\x3c\x4d",
    b"\x4d\x3c\xb2\xa1",
    b"\x0a\x0d\x0d\x0a",  # pcapng section header block
}

@asynccontextmanager
async def lifespan(_: FastAPI):
    """Fail loudly (in logs) at startup when tshark is missing (CLAUDE.md)."""
    logger = logging.getLogger("uvicorn.error")
    tshark_path = find_tshark()
    if tshark_path is None:
        logger.error("tshark NO detectado — /analyze devolverá 503. %s",
                     install_instructions())
    else:
        logger.info("tshark detectado en %s", tshark_path)
    yield


app = FastAPI(
    title="PCAP Analyzer API",
    version=__version__,
    description="Análisis de capturas .pcap/.pcapng basado en tshark.",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=config.CORS_ORIGINS,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(ai_router)

@app.get("/health")
def health() -> dict:
    tshark_path = find_tshark()
    return {
        "status": "ok",
        "version": __version__,
        "tshark": {
            "available": tshark_path is not None,
            "path": tshark_path,
            "version": tshark_version(tshark_path) if tshark_path else None,
            "install_hint": None if tshark_path else install_instructions(),
        },
        "ai": ai_availability(),
    }


def _save_upload(file: UploadFile) -> str:
    """Stream the upload to a temp file enforcing size and magic checks."""
    max_bytes = config.MAX_UPLOAD_MB * 1024 * 1024
    total = 0
    tmp = tempfile.NamedTemporaryFile(suffix=".pcap", delete=False)
    try:
        first_chunk = True
        while True:
            chunk = file.file.read(1024 * 1024)
            if not chunk:
                break
            if first_chunk:
                if chunk[:4] not in _PCAP_MAGICS:
                    raise HTTPException(
                        status_code=400,
                        detail="El archivo no parece un .pcap/.pcapng válido "
                        "(magic number desconocido).",
                    )
                first_chunk = False
            total += len(chunk)
            if total > max_bytes:
                raise HTTPException(
                    status_code=413,
                    detail="El archivo supera el máximo de %d MB." % config.MAX_UPLOAD_MB,
                )
            tmp.write(chunk)
        if total == 0:
            raise HTTPException(status_code=400, detail="El archivo está vacío.")
        tmp.close()
        return tmp.name
    except Exception:
        tmp.close()
        os.unlink(tmp.name)
        raise


@app.post("/analyze", response_model=AnalysisResult)
def analyze(file: UploadFile = File(...)) -> AnalysisResult:
    tshark_path = find_tshark()
    if tshark_path is None:
        raise HTTPException(status_code=503, detail=install_instructions())

    tmp_path = _save_upload(file)
    try:
        size_bytes = os.path.getsize(tmp_path)
        return analyze_pcap(
            tshark_path=tshark_path,
            pcap_path=tmp_path,
            original_filename=file.filename or "capture.pcap",
            size_bytes=size_bytes,
        )
    except TsharkTimeoutError as exc:
        raise HTTPException(status_code=504, detail=str(exc))
    except TsharkError as exc:
        raise HTTPException(
            status_code=422,
            detail="tshark no pudo procesar el archivo: %s" % exc,
        )
    finally:
        os.unlink(tmp_path)


@app.post("/analyze/async", status_code=202)
def analyze_async(file: UploadFile = File(...)) -> dict:
    """Queue a capture for background analysis (large files)."""
    tshark_path = find_tshark()
    if tshark_path is None:
        raise HTTPException(status_code=503, detail=install_instructions())

    tmp_path = _save_upload(file)
    job = job_store.submit(
        tshark_path=tshark_path,
        pcap_path=tmp_path,
        filename=file.filename or "capture.pcap",
        size_bytes=os.path.getsize(tmp_path),
    )
    return {"job_id": job.id, "status": job.status}


@app.get("/jobs/{job_id}")
def job_status(job_id: str) -> dict:
    job = job_store.get(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Trabajo no encontrado o expirado.")
    payload = {"job_id": job.id, "status": job.status, "filename": job.filename}
    if job.status == "done" and job.result is not None:
        payload["result"] = job.result.model_dump()
    elif job.status == "error":
        payload["error"] = job.error
    return payload


class ReportRequest(BaseModel):
    analysis: AnalysisResult
    diagnosis: Optional[str] = None


@app.post("/report")
def report(request: ReportRequest) -> Response:
    """Build the downloadable PDF report (Fase 4)."""
    pdf_bytes = build_report(request.analysis, request.diagnosis)
    safe_name = re.sub(r"[^A-Za-z0-9._-]", "_", request.analysis.file.name)
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": 'attachment; filename="informe-%s.pdf"' % safe_name
        },
    )
