"""Duplicate IP addresses: the same IP announced by several MACs via ARP."""
from __future__ import annotations

from typing import List

from ..models import Issue


def detect(state) -> List[Issue]:
    issues: List[Issue] = []
    for idx, (ip_addr, macs) in enumerate(state.arp_map.items()):
        if len(macs) < 2:
            continue
        mac_list = sorted(macs)
        issues.append(
            Issue(
                id="ip-duplicate-%d" % idx,
                type="ip_duplicate",
                severity="critical",
                title="IP duplicada: %s anunciada por %d MACs" % (ip_addr, len(macs)),
                detail=(
                    "La dirección %s fue anunciada por ARP desde %d MACs distintas "
                    "(%s). Conflicto de IP: dos equipos configurados con la misma "
                    "dirección o un posible ARP spoofing."
                    % (ip_addr, len(macs), ", ".join(mac_list))
                ),
                conversation=ip_addr,
                evidence={"ip": ip_addr, "macs": mac_list,
                          "announcements": sum(macs.values())},
            )
        )
    return issues
