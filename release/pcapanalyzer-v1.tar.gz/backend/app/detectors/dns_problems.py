"""DNS queries that never got a response or were answered too slowly."""
from __future__ import annotations

from typing import List

from .. import config
from ..models import Issue


def detect(state) -> List[Issue]:
    issues: List[Issue] = []
    unanswered = (query for pending in state.dns_pending.values() for query in pending)
    for idx, query in enumerate(unanswered):
        issues.append(
            Issue(
                id="dns-unanswered-%d" % idx,
                type="dns_unanswered",
                severity="warning",
                title="Consulta DNS sin respuesta",
                detail=(
                    "La consulta DNS de %s para '%s' al servidor %s nunca recibió "
                    "respuesta en la captura." % (query.client, query.name, query.server)
                ),
                conversation="%s <-> %s" % (query.client, query.server),
                evidence={"query_name": query.name, "server": query.server},
            )
        )
    for idx, exchange in enumerate(state.dns_answered):
        if exchange.latency_s <= config.DNS_SLOW_THRESHOLD_S:
            continue
        issues.append(
            Issue(
                id="dns-slow-%d" % idx,
                type="dns_slow",
                severity="warning",
                title="Respuesta DNS lenta (%.0f ms)" % (exchange.latency_s * 1000),
                detail=(
                    "La consulta DNS para '%s' tardó %.0f ms en ser respondida por %s "
                    "(umbral: %.0f ms)."
                    % (
                        exchange.name,
                        exchange.latency_s * 1000,
                        exchange.server,
                        config.DNS_SLOW_THRESHOLD_S * 1000,
                    )
                ),
                conversation="%s <-> %s" % (exchange.client, exchange.server),
                evidence={
                    "query_name": exchange.name,
                    "latency_ms": round(exchange.latency_s * 1000, 1),
                    "server": exchange.server,
                },
            )
        )
    return issues
