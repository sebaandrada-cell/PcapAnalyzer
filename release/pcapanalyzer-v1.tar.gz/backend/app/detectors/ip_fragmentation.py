"""IPv4 fragmentation: high fragmentation rate and datagrams that could not
be reassembled (missing last fragment)."""
from __future__ import annotations

from typing import List

from .. import config
from ..models import Issue


def detect(state) -> List[Issue]:
    issues: List[Issue] = []

    if state.packets and state.frag_packets:
        pct = 100.0 * state.frag_packets / state.packets
        if pct >= config.FRAG_HIGH_PCT:
            issues.append(
                Issue(
                    id="ip-fragmentation-high",
                    type="ip_fragmentation_high",
                    severity="warning",
                    title="Fragmentación IP elevada (%.1f%% de los paquetes)" % pct,
                    detail=(
                        "%d de %d paquetes son fragmentos IP (%.1f%%, umbral %.1f%%). "
                        "La fragmentación degrada el rendimiento y suele indicar un "
                        "MTU mal dimensionado (túneles, VPNs, jumbo frames)."
                        % (state.frag_packets, state.packets, pct,
                           config.FRAG_HIGH_PCT)
                    ),
                    evidence={
                        "fragment_packets": state.frag_packets,
                        "total_packets": state.packets,
                        "fragment_pct": round(pct, 2),
                        "datagrams": len(state.frag_groups),
                    },
                )
            )

    incomplete = {key: group for key, group in state.frag_groups.items()
                  if not group.has_last}
    if incomplete:
        samples = [
            {"src": key[0], "dst": key[1], "ip_id": key[2],
             "fragments_seen": group.packets}
            for key, group in list(incomplete.items())[:5]
        ]
        issues.append(
            Issue(
                id="ip-fragments-incomplete",
                type="ip_fragments_incomplete",
                severity="critical",
                title="Datagramas IP sin reensamblar (%d)" % len(incomplete),
                detail=(
                    "%d datagrama(s) fragmentado(s) nunca recibieron su último "
                    "fragmento en la captura: el receptor no pudo reensamblarlos y "
                    "esos datos se perdieron. Causa típica: un filtro o MTU que "
                    "descarta fragmentos." % len(incomplete)
                ),
                evidence={"incomplete_datagrams": len(incomplete),
                          "samples": samples},
            )
        )

    return issues
