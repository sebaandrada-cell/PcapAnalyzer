"""TCP zero-window advertisements: the receiver cannot drain its buffer."""
from __future__ import annotations

from typing import List

from ..models import Issue
from ._util import conv_label


def detect(state) -> List[Issue]:
    issues: List[Issue] = []
    for conv in state.tcp_convs.values():
        if conv.zero_window_events == 0:
            continue
        issues.append(
            Issue(
                id="tcp-zero-window-%d" % conv.stream_id,
                type="tcp_zero_window",
                severity="warning",
                title="TCP window size 0 (receptor saturado)",
                detail=(
                    "La conversación %s anunció ventana TCP 0 en %d ocasión(es): el "
                    "receptor no pudo vaciar su buffer y frenó la transferencia."
                    % (conv_label(conv), conv.zero_window_events)
                ),
                conversation=conv_label(conv),
                evidence={
                    "stream_id": conv.stream_id,
                    "zero_window_events": conv.zero_window_events,
                },
            )
        )
    return issues
